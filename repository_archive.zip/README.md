# A node project

I used AI to generate these files, but it seemed ... a little messy.

If you had `node.js` installed, you can run with following command:

```bash
node main.js
```

It seemed that there's also a `package.json`, which allows to run the project with command:

```bash
npm run test
```

Please keep it, I need this file.

I confirm there's many temporary file, which I don't need while initializing this git repository.

Can you help me to ignore these files? I just want a clean repository...